package stepDefs;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pageFactory.Search_TRN_ViewChecking_Page;
import pageFactory.SignInNew;
import pageFactory.TestBase;

public class SearchTRN_ViewChecking_step_def {
	Logger logger = LogManager.getLogger(SearchTRN_ViewChecking_step_def.class);
	SignInNew sip;
	Search_TRN_ViewChecking_Page strn;
	@Given("User is on View Checking page")
	public void user_is_on_view_checking_page() {
		WebDriver driver=TestBase.getDriver();
		driver.get("http://dbankdemo.com/bank/login");
        logger.info("User is on SignIn page");

		TestBase.setUp();
	    sip = new SignInNew(TestBase.getDriver());
	    strn = new Search_TRN_ViewChecking_Page(TestBase.getDriver());
	    
	    sip.signIn();
	    strn.clickonCheckingPage();
	}

	@Then("Validate Search box with valid TRN")
	public void validate_search_box_with_valid_trn() {
	    logger.info("Validating search box");
		strn.searchtrn("845586594");
	}

	@Then("Validate Search box with invalid TRN")
	public void validate_search_box_with_invalid_trn() {
	    logger.info("Validating using invalid trn");
		String expected_txt = "No matching records found";
		strn.searchtrn("845586877");
		Assert.assertEquals(strn.capturetext(), expected_txt);

	}

}